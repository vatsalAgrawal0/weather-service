package com.scalable.weather.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.scalable.weather.dto.WeatherResponse;

@Service
public class WeatherService {


    private String apiKey = "5796abbde9106b7da4febfae8c44c232";

    public WeatherResponse getWeatherForCity(String city) {
        String url = String.format(
            "https://api.openweathermap.org/data/2.5/find?q=%s&appid=%s&units=metric",
            city, apiKey
        );

        RestTemplate restTemplate = new RestTemplate();
        return restTemplate.getForObject(url, WeatherResponse.class);
    }
}
