package com.scalable.weather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
